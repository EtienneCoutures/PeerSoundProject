# PlugIn-PeerSoundProject
it's an extension for my EIP (epitech)
PeerSoundProject est un projet créé dans le cadre de fin d'étude à Epitech par des étudiants tous passionnés de musiques.
Notre but est simple, nous voulons permettre aux gens qui aiment le même type de musique de se regrouper entre eux pour découvrir ou partager leurs perles musicales.
Tout en recréant l'interaction d'avant lorsque l'on se prétait des disques entre collègues.
Quel que soit vos gouts, d'autres les partagent.
Notre solution est simple, sans pubs ni de contenus sponsorisés.
Vous écoutez une musique par exemple de rock indé des années 90 sur une plateforme tel que Youtube, SoundCloud, Deezer. 
Cette musique vous plait et vous voulez la partager dans un groupe dédié au rock indé.
Pour cela il vous suffira de cliquer sur le plugIn afin qu'il récupére la musique, et la rajoute au groupe voulu.
Vous pourrez depuis le plugIn lire les musiques de vos différents groupes sans avoir besoin d'une page de navigation spécifique ouverte.
